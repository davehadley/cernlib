#define WIN32

#include <io.h>

int _stdcall INTRAC(dummy)

{
    return (((int) isatty(0)!=0) ? 1 : 0) ;
}

