int intrac_()
{
    return ((int) isatty(0));
}
