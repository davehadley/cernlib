/*
 * $Id: chain1.h,v 1.1.1.1 1996/03/01 11:39:14 mclareni Exp $
 *
 * $Log: chain1.h,v $
 * Revision 1.1.1.1  1996/03/01 11:39:14  mclareni
 * Paw
 *
 */
/*CMZ :  2.03/07 23/08/93  19.26.40  by  Fons Rademakers*/
/*-- Author :*/
#define  pchlst    pchlst_
#define  pchdel    pchdel_
#define  pchadd    pchadd_
#define  pchpat    pchpat_
#define  pchset    pchset_
#define  pchnxt    pchnxt_
#define  pischn    pischn_
#define  piscpf    piscpf_
#define  pchevt    pchevt_
#define  pchcnt    pchcnt_
#define  pchtop    pchtop_
