/*
 * $Id: chain3.h,v 1.1.1.1 1996/03/01 11:39:14 mclareni Exp $
 *
 * $Log: chain3.h,v $
 * Revision 1.1.1.1  1996/03/01 11:39:14  mclareni
 * Paw
 *
 */
/*CMZ :  2.03/07 23/08/93  19.27.56  by  Fons Rademakers*/
/*-- Author :*/
#define  pchlst    PCHLST
#define  pchdel    PCHDEL
#define  pchadd    PCHADD
#define  pchpat    PCHPAT
#define  pchset    PCHSET
#define  pchnxt    PCHNXT
#define  pischn    PISCHN
#define  piscpf    PISCPF
#define  pchevt    PCHEVT
#define  pchcnt    PCHCNT
#define  pchtop    PCHTOP
