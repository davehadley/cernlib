/*
 * $Id: pawlunc.h,v 1.1.1.1 1996/03/01 11:39:13 mclareni Exp $
 *
 * $Log: pawlunc.h,v $
 * Revision 1.1.1.1  1996/03/01 11:39:13  mclareni
 * Paw
 *
 */
/*CMZ :  2.00/02 14/01/93  15.43.33  by  Rene Brun*/
/*-- Author :*/
#if !defined(CERNLIB_APOF77)
#include "pawlunf.h"
#endif
#if defined(CERNLIB_APOF77)
#include "pawlun7.h"
#endif

