dbl 	MLP_Sigmoide(dbl x);
void 	MLP_vSigmoide(dbl *x, int n);
void 	MLP_vSigmoideDeriv(dbl *x, dbl *dy, int n);
