void NewPiaf(){}
void UnpackLabels(){}
void PackLabels(){}
void PiafNoEvt(){}
void _stdcall PZSYNC(int i){}
void _stdcall PFLOCL(int i,int i1,int i2,int i3,int i4,int i5){}
void _stdcall PACKCUT(int i,int i1,int i2,int i3){}
void _stdcall ICUTTYPE(int i){}
void _stdcall MAXCUTS(){}
void _stdcall PZCXIO(int i,int i1){}
void _stdcall PZSETUP(int i,int i1,int i2,int i3,int i4,int i5, int i6,int i7,int i8,int i9){}
void _stdcall PZXFER(int i,int i1,int i2,int i3,int i4,int i5, int i6,int i7){}
void _stdcall PACKGCUT(int i,int i1,int i2,int i3,int i4,int i5, int i6){}
int _stdcall IFPSCL(float *X){return 0;/* It is called by HBOOK/HFPBUG(X,ROUT,ID) */ }