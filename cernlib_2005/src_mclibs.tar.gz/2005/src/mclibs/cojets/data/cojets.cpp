#include "table.cin"
#include "decay.cin"
