#if 0
*       for MAC II, MPW shell, LSE compiler
* This pilot patch was created from kernmpw.car patch _kmpw
* This directory was created from kernmpw.car patch qmmpw
* This directory was created from kernfor.car patch qmmpw
*               ISA standard routines, ISHFT, IOR, etc
*                 IEEE floating point
#endif
#ifndef CERNLIB_QMMPW
#define CERNLIB_QMMPW
#endif
#ifndef CERNLIB_F77
#define CERNLIB_F77
#endif
#ifndef CERNLIB_QIEEE
#define CERNLIB_QIEEE
#endif
#ifndef CERNLIB_QISASTD
#define CERNLIB_QISASTD
#endif
#ifndef CERNLIB_QORTHOLL
#define CERNLIB_QORTHOLL
#endif
#ifndef CERNLIB_QINTZERO
#define CERNLIB_QINTZERO
#endif
