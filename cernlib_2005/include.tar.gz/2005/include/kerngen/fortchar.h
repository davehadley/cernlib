/*
* $Id: fortchar.h,v 1.1.1.1 1996/02/15 17:49:18 mclareni Exp $
*
* $Log: fortchar.h,v $
* Revision 1.1.1.1  1996/02/15 17:49:18  mclareni
* Kernlib
*
*
*   for C routines receiving a Fortran Character string
*
* fortchar.inc
*/
#if defined(CERNLIB_QMCRY)
#include <fortran.h>
#endif
