#if 0
#endif
#if !defined(CERNLIB_SINGLE)
#ifndef CERNLIB_DOUBLE
#define CERNLIB_DOUBLE
#endif
#endif
#ifndef CERNLIB_IBM
#define CERNLIB_IBM
#endif
