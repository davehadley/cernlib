/*
    StdHep counting common block
*/
extern struct stdcnt {
    int nstdwrt;	/* number of events written */
    int nstdrd;		/* number of events read */
} stdcnt_;
