/*
 * $Id: browh1.h,v 1.1.1.1 1996/03/08 15:33:01 mclareni Exp $
 *
 * $Log: browh1.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:01  mclareni
 * Kuip
 *
 */
#ifndef _brow_h1
#define _brow_h1

#include "kbrow.h"

#endif /* _brow_h1 */

