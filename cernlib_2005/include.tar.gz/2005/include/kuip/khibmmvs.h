/*
 * $Id: khibmmvs.h,v 1.1.1.1 1996/03/08 15:33:00 mclareni Exp $
 *
 * $Log: khibmmvs.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:00  mclareni
 * Kuip
 *
 */
#ifndef IBMMVS
#  define IBMMVS
#endif

