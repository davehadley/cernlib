/*
 * $Id: khibmvm.h,v 1.1.1.1 1996/03/08 15:33:00 mclareni Exp $
 *
 * $Log: khibmvm.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:00  mclareni
 * Kuip
 *
 */
#ifndef IBMVM
#  define IBMVM
#endif

