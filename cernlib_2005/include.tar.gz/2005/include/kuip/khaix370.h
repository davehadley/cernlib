/*
 * $Id: khaix370.h,v 1.1.1.1 1996/03/08 15:33:00 mclareni Exp $
 *
 * $Log: khaix370.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:00  mclareni
 * Kuip
 *
 */
#ifndef AIX370
#  define AIX370
#endif

