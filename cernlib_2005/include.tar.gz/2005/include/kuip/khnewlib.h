/*
 * $Id: khnewlib.h,v 1.1.1.1 1996/03/08 15:33:00 mclareni Exp $
 *
 * $Log: khnewlib.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:00  mclareni
 * Kuip
 *
 */
#ifndef NEWLIB
#  define NEWLIB
#endif


