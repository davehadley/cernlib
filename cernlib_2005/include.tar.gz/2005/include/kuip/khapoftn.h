/*
 * $Id: khapoftn.h,v 1.1.1.1 1996/03/08 15:33:00 mclareni Exp $
 *
 * $Log: khapoftn.h,v $
 * Revision 1.1.1.1  1996/03/08 15:33:00  mclareni
 * Kuip
 *
 */
#ifndef APOLLO_FTN
#  define APOLLO_FTN
#endif

